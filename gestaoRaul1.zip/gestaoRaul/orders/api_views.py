from rest_framework import viewsets, permissions
from .models import Order
from .serializers import OrderSerializer
from django.utils import timezone

class OrderViewSet(viewsets.ModelViewSet):
    queryset = Order.objects.all()
    serializer_field = OrderSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        # Filtrar pedidos das últimas 15 horas como na view original
        fifteen_hours_ago = timezone.now() - timezone.timedelta(hours=15)
        return Order.objects.filter(queue__gte=fifteen_hours_ago).order_by('-queue')

    def get_serializer_class(self):
        return OrderSerializer
